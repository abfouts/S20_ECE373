/*
 * Abram Fouts
 * 5/1/2020
 * ECE 373
 *
 * Homework 3 : Blinking LED
 */

#include <linux/module.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/pci.h>
#include <linux/netdevice.h>

#define DEVCNT 1
#define DEVNAME "Abram_Fouts_HW3"
#define LEDOFFSET 0x00000E00

char driverName[] = DEVNAME;

static struct mydev_dev {
	struct cdev my_cdev;
	dev_t mydev_node;
	/* more stuff will go in here later... */
	//int sys_int;
    int syscall_val;
	__u32 myLED_reg;
	__u32 led_initial;
} mydev;

static dev_t mydev_node;

//PCI struct def
static struct mypci_pci {
	struct pci_dev *pdev;
	void *hw_addr;

} mypci_pci;

//PCI ID TABLE
static const struct pci_device_id pci_ID[] = {
	{PCI_DEVICE(0x8086, 0x100e)},
	{},
};

static int usrVar = 0xF;
module_param(usrVar, int, S_IRUSR | S_IWUSR);

//static int exam = 15;
//module_param(exam, int, S_IRUSR | S_IWUSR);

/* this doesn't appear in /sys/modules */
//static int exam_nosysfs = 25;
//module_param(exam_nosysfs, int, 0);

//////////////////////////////////////////////////////////////////////////////
// Open
static int LED_open(struct inode *inode, struct file *file)
{
	printk(KERN_INFO "successfully opened!\n");

	//mydev.sys_int = 23;
    //user parameter assigns syscall_val
    mydev.syscall_val = usrVar;
	return 0;
}

//////////////////////////////////////////////////////////////////////////////
// Write
static ssize_t LED_read(struct file *file, char __user *buf,
                             size_t len, loff_t *offset)
{
	/* Get a local kernel buffer set aside */
	int ret;
    printk(KERN_INFO "We are in LED_read\n");

	//Get the LED REG value, 0xE00 from part 1 of HW3
	mydev.myLED_reg = ioread32(mypci_pci.hw_addr + LEDOFFSET);	//Mask all bits except the ones to change

	if (*offset >= sizeof(int))
		return 0;

	/* Make sure our user wasn't bad... */
	if (!buf) {
		ret = -EINVAL;
		goto out;
	}

	if (copy_to_user(buf, &mydev.myLED_reg, sizeof(int))) {
		ret = -EFAULT;
		goto out;
	}
	ret = sizeof(int);
	*offset += sizeof(int);

	/* Good to go, so printk the thingy */
    //Replaced example 5 sys_int with syscall_val
	printk(KERN_INFO "User got from us %d\n", mydev.myLED_reg);

out:
	return ret;
}

//////////////////////////////////////////////////////////////////////////////
//Write
static ssize_t LED_write(struct file *file, const char __user *buf,
                              size_t len, loff_t *offset)
{
	/* Have local kernel memory ready */
	char *kern_buf;
	int ret;

    printk(KERN_INFO "We are in LED_write\n");

	/* Make sure our user isn't bad... */
	if (!buf) {
		ret = -EINVAL;
		goto out;
	}

	/* Get some memory to copy into... */
	kern_buf = kmalloc(len, GFP_KERNEL);

	/* ...and make sure it's good to go */
	if (!kern_buf) {
		ret = -ENOMEM;
		goto out;
	}

	/* Copy from the user-provided buffer */
	if (copy_from_user(kern_buf, buf, len)) {
		/* uh-oh... */
		ret = -EFAULT;
		goto mem_out;
	}

	ret = len;

    //Write to syscall_val
    //mydev.syscall_val = *kern_buf; //no longer need to write to a char val

	//Do IO write what the user wants to the BAR + offset address
	iowrite32(*kern_buf, (mypci_pci.hw_addr + LEDOFFSET));
	
	/* print what userspace gave us */
	printk(KERN_INFO "Userspace wrote \"%x\" to us\n", *kern_buf);	//May need to cast
	
	//printk(KERN_INFO "Userspace wrote \"%s\" to us\n", kern_buf);

	//sleep for two seconds or 2000 m seconds
	msleep(2000);

mem_out:
	kfree(kern_buf);
out:
	return ret;
}

//////////////////////////////////////////////////////////////////////////////
//Let's get probing like we're ET
static int pci_probe(struct pci_dev *pdev, const struct pci_device_id *ent) {
	
	resource_size_t mmio_start, mmio_len;
	unsigned long mask;

	printk(KERN_INFO "We are in PCI Probe\n");

	//select bar for pdev
	mask = pci_select_bars(pdev, IORESOURCE_MEM); //maybe not
	printk(KERN_INFO "The bar mask is %lx \n", mask);
	
	// Reserve
	if(pci_request_selected_regions(pdev, mask, driverName)) {
		printk(KERN_ERR "Failed to select region\n");
		pci_release_selected_regions(pdev, pci_select_bars(pdev, IORESOURCE_MEM));
	}

	mmio_start = pci_resource_start(pdev, 0);
	mmio_len = pci_resource_len(pdev, 0);

	if (!(mypci_pci.hw_addr = ioremap(mmio_start, mmio_len))) {
		printk(KERN_INFO "I/O Remapping Failed\n");
		iounmap(mypci_pci.hw_addr);
		pci_release_selected_regions(pdev, pci_select_bars(pdev, IORESOURCE_MEM));
	}

	pci_enable_device(pdev);

	//We have passed
	mydev.led_initial = ioread32(mypci_pci.hw_addr + LEDOFFSET);	//May need to change to add
	printk(KERN_INFO "LED_initial = %x\n", mydev.led_initial);

	return 0;
}

//////////////////////////////////////////////////////////////////////////////
//Get this punk driver out of here -- remove
static void pci_remove(struct pci_dev *pdev){
	iounmap(mypci_pci.hw_addr);
	pci_release_selected_regions(pdev, pci_select_bars(pdev, IORESOURCE_MEM));
	printk(KERN_INFO "PCI Driver Removed\n");
}

//////////////////////////////////////////////////////////////////////////////
/* File operations for our device */
static struct file_operations mydev_fops = {
	.owner = THIS_MODULE,
	.open = LED_open,
	.read = LED_read,
	.write = LED_write,
};

//////////////////////////////////////////////////////////////////////////////
//Set up the pci driver similar to file operations
static struct pci_driver mypci_driver = {
	.name = "LED Driver",
	.id_table = pci_ID,
	.probe = pci_probe,
	.remove = pci_remove,	
};

//////////////////////////////////////////////////////////////////////////////
// Init
static int __init LED_init(void)
{
	printk(KERN_INFO "%s module loading... syscall_val=%d\n", DEVNAME, mydev.syscall_val);

	if (alloc_chrdev_region(&mydev_node, 0, DEVCNT, DEVNAME)) {
		printk(KERN_ERR "alloc_chrdev_region() failed!\n");
		return -1;
	}

	printk(KERN_INFO "Allocated %d devices at major: %d\n", DEVCNT,
	       MAJOR(mydev_node));

	/* Initialize the character device and add it to the kernel */
	cdev_init(&mydev.my_cdev, &mydev_fops);
	mydev.my_cdev.owner = THIS_MODULE;

	if (cdev_add(&mydev.my_cdev, mydev_node, DEVCNT)) {
		printk(KERN_ERR "cdev_add() failed!\n");

		/* clean up chrdev allocation */
		unregister_chrdev_region(mydev_node, DEVCNT);

		return -1;
	}

	//Do the PCI driver stuff here
	if (pci_register_driver(&mypci_driver)){
		printk(KERN_INFO "PCI reg failed\n");
		pci_unregister_driver(&mypci_driver);			//clean up
		unregister_chrdev_region(mydev_node, DEVCNT);	//clean up

		return -1;
	}
	return 0;
}

//////////////////////////////////////////////////////////////////////////////
//Exit
static void __exit LED_exit(void)
{
	//Bye bye PCI
	pci_unregister_driver(&mypci_driver);	//clean up

	/* destroy the cdev */
	cdev_del(&mydev.my_cdev);

	/* clean up the devices */
	unregister_chrdev_region(mydev_node, DEVCNT);

	printk(KERN_INFO "%s module unloaded!\n", DEVNAME);
}

MODULE_AUTHOR("Abram Fouts");
MODULE_LICENSE("GPL");
MODULE_VERSION("0.2");
module_init(LED_init);
module_exit(LED_exit);
