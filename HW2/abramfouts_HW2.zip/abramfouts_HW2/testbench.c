#include "stdlib.h"
#include "stdio.h"
#include "errno.h"
#include "unistd.h"
#include "fcntl.h"

int main() {

    int fd = open("/dev/hw2char", O_RDWR);
    int usrVar = 0;

    if(fd < 0) {
        printf("Unknown File\n");
        return errno;
    } 

    //Read the file
    if(read(fd, &usrVar, sizeof(int)) < 0) {
        printf("Read Error\n");
        return errno;
    }
    
    //Print value that was read
    printf("Value from the driver: %d\n", usrVar);

    //Get new valur to send
    printf("Please type your favorite number: ");
    scanf("%d", &usrVar);

    //write to the file
    if(write(fd, &usrVar, sizeof(int)) < 0) {
        printf("Write Error\n"); 
        return errno;
    }

    //Repeat to make sure the write happened
    //Read the file
    if(read(fd, &usrVar, sizeof(int)) < 0) {
        printf("Read Error\n");
        return errno;
    }
    
    //Print value that was read
    printf("Value from the driver: %d\n", usrVar);

    close(fd);
    return 0;
}