/*
 * Abram Fouts
 * 4/18/2020
 * ECE 373
 *
 * Homework 2 : Character Driver
 */

#include <linux/module.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/uaccess.h>

#define DEVCNT 1
#define DEVNAME "Abram_Fouts_HW2"

static struct mydev_dev {
	struct cdev my_cdev;
	dev_t mydev_node;
	/* more stuff will go in here later... */
	//int sys_int;
    int syscall_val;
} mydev;

static dev_t mydev_node;

static int usrVar = 40;
module_param(usrVar, int, S_IRUSR | S_IWUSR);

//static int exam = 15;
//module_param(exam, int, S_IRUSR | S_IWUSR);

/* this doesn't appear in /sys/modules */
//static int exam_nosysfs = 25;
//module_param(exam_nosysfs, int, 0);

static int charDev_open(struct inode *inode, struct file *file)
{
	printk(KERN_INFO "successfully opened!\n");

	//mydev.sys_int = 23;
    //user parameter assigns syscall_val
    mydev.syscall_val = usrVar;
	return 0;
}

static ssize_t charDev_read(struct file *file, char __user *buf,
                             size_t len, loff_t *offset)
{
	/* Get a local kernel buffer set aside */
	int ret;
    printk(KERN_INFO "We are in charDev_read");

	if (*offset >= sizeof(int))
		return 0;

	/* Make sure our user wasn't bad... */
	if (!buf) {
		ret = -EINVAL;
		goto out;
	}

	if (copy_to_user(buf, &mydev.syscall_val, sizeof(int))) {
		ret = -EFAULT;
		goto out;
	}
	ret = sizeof(int);
	*offset += sizeof(int);

	/* Good to go, so printk the thingy */
    //Replaced example 5 sys_int with syscall_val
	printk(KERN_INFO "User got from us %d\n", mydev.syscall_val);

out:
	return ret;
}

static ssize_t charDev_write(struct file *file, const char __user *buf,
                              size_t len, loff_t *offset)
{
	/* Have local kernel memory ready */
	char *kern_buf;
	int ret;

    printk(KERN_INFO "We are in charDev_write");

	/* Make sure our user isn't bad... */
	if (!buf) {
		ret = -EINVAL;
		goto out;
	}

	/* Get some memory to copy into... */
	kern_buf = kmalloc(len, GFP_KERNEL);

	/* ...and make sure it's good to go */
	if (!kern_buf) {
		ret = -ENOMEM;
		goto out;
	}

	/* Copy from the user-provided buffer */
	if (copy_from_user(kern_buf, buf, len)) {
		/* uh-oh... */
		ret = -EFAULT;
		goto mem_out;
	}

	ret = len;

    //Write to syscall_val
    mydev.syscall_val = *kern_buf;
	
	/* print what userspace gave us */
	printk(KERN_INFO "Userspace wrote \"%d\" to us\n", mydev.syscall_val);
	//printk(KERN_INFO "Userspace wrote \"%s\" to us\n", kern_buf);

mem_out:
	kfree(kern_buf);
out:
	return ret;
}

/* File operations for our device */
static struct file_operations mydev_fops = {
	.owner = THIS_MODULE,
	.open = charDev_open,
	.read = charDev_read,
	.write = charDev_write,
};

static int __init charDev_init(void)
{
	printk(KERN_INFO "%s module loading... syscall_val=%d\n", DEVNAME, mydev.syscall_val);

	if (alloc_chrdev_region(&mydev_node, 0, DEVCNT, DEVNAME)) {
		printk(KERN_ERR "alloc_chrdev_region() failed!\n");
		return -1;
	}

	printk(KERN_INFO "Allocated %d devices at major: %d\n", DEVCNT,
	       MAJOR(mydev_node));

	/* Initialize the character device and add it to the kernel */
	cdev_init(&mydev.my_cdev, &mydev_fops);
	mydev.my_cdev.owner = THIS_MODULE;

	if (cdev_add(&mydev.my_cdev, mydev_node, DEVCNT)) {
		printk(KERN_ERR "cdev_add() failed!\n");

		/* clean up chrdev allocation */
		unregister_chrdev_region(mydev_node, DEVCNT);

		return -1;
	}

	return 0;
}

static void __exit charDev_exit(void)
{
	/* destroy the cdev */
	cdev_del(&mydev.my_cdev);

	/* clean up the devices */
	unregister_chrdev_region(mydev_node, DEVCNT);

	printk(KERN_INFO "%s module unloaded!\n", DEVNAME);
}

MODULE_AUTHOR("Abram Fouts");
MODULE_LICENSE("GPL");
MODULE_VERSION("0.2");
module_init(charDev_init);
module_exit(charDev_exit);
